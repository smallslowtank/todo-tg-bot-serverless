"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.keyboard_help_list_create = exports.keyboard_help_list = exports.keyboard_list = exports.keyboard_help = void 0;
const telegraf_1 = require("telegraf");
exports.keyboard_help = telegraf_1.Markup.inlineKeyboard([
    telegraf_1.Markup.button.callback('Help page', 'task_help'),
]);
exports.keyboard_list = telegraf_1.Markup.inlineKeyboard([
    telegraf_1.Markup.button.callback("List Task 📝", "task_list"),
]);
exports.keyboard_help_list = telegraf_1.Markup.inlineKeyboard([
    telegraf_1.Markup.button.callback('Help page', 'task_help'),
    telegraf_1.Markup.button.callback("List Task 📝", "task_list"),
]);
exports.keyboard_help_list_create = telegraf_1.Markup.inlineKeyboard([
    [
        telegraf_1.Markup.button.callback('Help page', 'task_help'),
        telegraf_1.Markup.button.callback("List Task 📝", "task_list"),
    ],
    [
        telegraf_1.Markup.button.callback("Add this message as a new Task", "msg_to_task"),
    ]
]);
