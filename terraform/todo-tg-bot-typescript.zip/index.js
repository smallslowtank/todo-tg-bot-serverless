"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const telegraf_1 = require("telegraf");
const config_service_1 = require("./config/config.service");
const base_commands_1 = require("./commands/base.commands");
const echo_command_1 = require("./commands/echo.command");
const todo_commands_1 = require("./commands/todo.commands");
class Bot {
    constructor() {
        this.bot = new telegraf_1.Telegraf(config_service_1.configService.get("BOT_TOKEN"));
        this.tg_id = Number(config_service_1.configService.get("TG_ID"));
        this.commands = [];
    }
    //init() {
    init(message) {
        return __awaiter(this, void 0, void 0, function* () {
            // Filter by telegram ID
            this.bot.drop(ctx => {
                if (ctx.from && ctx.from.id !== this.tg_id) {
                    return true;
                }
                else {
                    return false;
                }
                ;
            });
            // Filter by chat type
            this.bot.drop(ctx => {
                if (ctx.message && ctx.message.chat.type !== 'private') {
                    return true;
                }
                else {
                    return false;
                }
                ;
            });
            // Add routers (Echo router should come at the end!!!)
            this.commands = [
                new base_commands_1.BaseCommands(this.bot),
                new todo_commands_1.TodoCommands(this.bot),
                new echo_command_1.Echo(this.bot)
            ];
            for (const command of this.commands) {
                command.handle();
            }
            // Start bot
            this.bot.handleUpdate(message);
        });
    }
    ;
}
;
// Entry point for Cloud Function (webhook)
module.exports.handler = function (event, context) {
    return __awaiter(this, void 0, void 0, function* () {
        const message = JSON.parse(event['messages'][0]['details']['message']['body']);
        const bot = new Bot();
        yield bot.init(message);
    });
};
