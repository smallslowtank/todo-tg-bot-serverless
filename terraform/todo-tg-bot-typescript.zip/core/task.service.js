"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.taskService = exports.TaskService = void 0;
const database_service_1 = require("../database/database.service");
class TaskService {
    create(task_title) {
        return __awaiter(this, void 0, void 0, function* () {
            if (yield database_service_1.databaseService.task_exist(task_title)) {
                return false;
            }
            else {
                database_service_1.databaseService.task_create(task_title);
                return true;
            }
            ;
        });
    }
    ;
    get_all() {
        return __awaiter(this, void 0, void 0, function* () {
            let result = [];
            let res = yield database_service_1.databaseService.task_get_all();
            if (res[0] === undefined) {
                result = ['Список пуст'];
            }
            else {
                for (let i in res) {
                    result.push(res[i]['task_title']);
                }
                ;
            }
            ;
            return result;
        });
    }
    ;
    complete(task_for_completing) {
        return __awaiter(this, void 0, void 0, function* () {
            let list_of_tasks = yield database_service_1.databaseService.task_get_all();
            if (0 < task_for_completing && task_for_completing <= list_of_tasks.length) {
                let task_id = list_of_tasks[task_for_completing - 1]['task_id'];
                if (yield database_service_1.databaseService.task_completed(task_id)) {
                    return true;
                }
                else {
                    return false;
                }
                ;
            }
            else {
                return false;
            }
            ;
        });
    }
    ;
}
exports.TaskService = TaskService;
;
exports.taskService = new TaskService();
