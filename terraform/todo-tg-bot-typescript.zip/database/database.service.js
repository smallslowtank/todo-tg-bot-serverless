"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.databaseService = exports.DataBaseService = void 0;
const config_service_1 = require("../config/config.service");
const metadata_1 = require("@ydbjs/auth/metadata");
const core_1 = require("@ydbjs/core");
const query_1 = require("@ydbjs/query");
class DataBaseService {
    constructor() {
        this.cloud_id = config_service_1.configService.get("CLOUD_ID");
        this.db_id = config_service_1.configService.get("DB_ID");
        this.ydb_cs = `grpcs://ydb.serverless.yandexcloud.net:2135/?database=/ru-central1/${this.cloud_id}/${this.db_id}`;
        this.credentialsProvider = new metadata_1.MetadataCredentialsProvider();
    }
    formatToYYYYMMDDHHmmss() {
        return __awaiter(this, void 0, void 0, function* () {
            const date = new Date;
            const year = date.getFullYear();
            const month = String(date.getMonth() + 1).padStart(2, '0'); // Month is 0-indexed
            const day = String(date.getDate()).padStart(2, '0');
            const hours = String(date.getHours()).padStart(2, '0');
            const minutes = String(date.getMinutes()).padStart(2, '0');
            const seconds = String(date.getSeconds()).padStart(2, '0');
            return Number(`${year}${month}${day}${hours}${minutes}${seconds}`);
        });
    }
    ;
    // инициализация базы данных
    initDb() {
        return __awaiter(this, void 0, void 0, function* () {
            const driver = new core_1.Driver(this.ydb_cs, {
                'credentialsProvider': this.credentialsProvider,
                'ydb.sdk.enable_discovery': false, // Улучшает производительность холодного старта
            });
            return driver;
        });
    }
    ;
    task_exist(task_title) {
        return __awaiter(this, void 0, void 0, function* () {
            const driver = yield this.initDb();
            yield driver.ready();
            let sql = (0, query_1.query)(driver);
            let result = false;
            try {
                const [resultSets] = yield sql(`
                SELECT task_title
                FROM tasks
                WHERE task_title = '${task_title}' AND task_completed = FALSE
            `);
                if (resultSets[0]) {
                    result = true;
                }
                ;
            }
            finally {
                driver.close();
                return result;
            }
            ;
        });
    }
    ;
    task_create(task_title) {
        return __awaiter(this, void 0, void 0, function* () {
            const driver = yield this.initDb();
            yield driver.ready();
            let sql = (0, query_1.query)(driver);
            let result = false;
            const task_id = yield this.formatToYYYYMMDDHHmmss();
            const task_completed = false;
            try {
                yield sql(`
                INSERT INTO tasks (task_id, task_title, task_completed)
                VALUES (${task_id}, '${task_title}', ${task_completed})
            `);
                result = true;
            }
            finally {
                driver.close();
                return result;
            }
            ;
        });
    }
    ;
    task_get_all() {
        return __awaiter(this, void 0, void 0, function* () {
            const driver = yield this.initDb();
            yield driver.ready();
            let sql = (0, query_1.query)(driver);
            let result = [];
            let result_query = [];
            try {
                const resultSets = yield sql(`
                SELECT task_id, task_title
                FROM tasks
                WHERE task_completed = FALSE
                ORDER BY task_id ASC;
            `);
                const result_json = JSON.stringify(resultSets, (key, value) => {
                    return typeof value === 'bigint' ? Number(value) : value;
                });
                result_query = JSON.parse(result_json);
                result = result_query[0];
            }
            finally {
                driver.close();
                // результат запроса в виде списка из объектов [{task_id: number, task_title: string}]
                return result;
            }
            ;
        });
    }
    ;
    task_completed(task_id) {
        return __awaiter(this, void 0, void 0, function* () {
            const driver = yield this.initDb();
            yield driver.ready();
            let sql = (0, query_1.query)(driver);
            let result = false;
            try {
                yield sql(`
                UPDATE tasks
                SET task_completed = TRUE
                WHERE task_id = ${task_id};
            `);
                result = true;
            }
            finally {
                driver.close();
                return result;
            }
            ;
        });
    }
    ;
}
exports.DataBaseService = DataBaseService;
;
exports.databaseService = new DataBaseService();
/*
async task_get_all(): Promise<any[][]> {

    const driver = await this.initDb();
    await driver.ready();

    let sql = query(driver);

    let result: any[][] = [];
    try {
        // Выполняем запрос
        const resultSets = await sql(`
            SELECT task_id, task_title, task_completed
            FROM tasks
            WHERE task_completed = FALSE
            ORDER BY task_id ASC;
        `);
        const result_json = JSON.stringify(resultSets, (key, value) => {
            return typeof value === 'bigint' ? Number(value) : value;
        });
        result = JSON.parse(result_json);
    } finally {
        // ОБЯЗАТЕЛЬНО закрываем драйвер
        driver.close();
        // Возвращаем результат запроса в виде списка из списка объектов
        // [[{task_id: number, task_title: string, task_completed: boolean}]]
        return result;
    };
};
*/
