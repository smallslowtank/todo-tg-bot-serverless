"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TodoCommands = void 0;
exports.create_list_of_tasks = create_list_of_tasks;
const command_class_1 = require("./command.class");
const task_service_1 = require("../core/task.service");
const inline_1 = require("../keyboards/inline");
// формирование списка текущих задач для сообщения
function create_list_of_tasks() {
    return __awaiter(this, void 0, void 0, function* () {
        const list_tasks = yield task_service_1.taskService.get_all();
        let text = "";
        let count_task = 1;
        for (let i in list_tasks) {
            if (list_tasks[i] != "Список пуст") {
                text = text + `${count_task} ${list_tasks[i]} \n`;
                count_task += 1;
            }
            else {
                text = list_tasks[i];
            }
            ;
        }
        ;
        return text;
    });
}
;
class TodoCommands extends command_class_1.Command {
    handle() {
        // task_list callback (список задач)
        this.bot.action('task_list', (ctx) => __awaiter(this, void 0, void 0, function* () {
            let list_of_task = yield create_list_of_tasks();
            ctx.editMessageText(`📝 ToDo Bot\nСписок задач:\n${list_of_task}`, inline_1.keyboard_help);
        }));
        // msg_to_task callback (создать новую задачу из текста сообщения)
        this.bot.action('msg_to_task', (ctx) => __awaiter(this, void 0, void 0, function* () {
            let task_title = String(ctx.text);
            if (yield task_service_1.taskService.create(task_title)) {
                ctx.editMessageText(`📝 ToDo Bot\nДобавлена задача:\n${task_title}`, inline_1.keyboard_help_list);
            }
            else {
                ctx.editMessageText(`📝 ToDo Bot\nУже есть задача:\n${task_title}`, inline_1.keyboard_help_list);
            }
            ;
        }));
        // del command (удалить задачу из списка невыполненных)
        this.bot.hears(/^\/del /, (ctx) => __awaiter(this, void 0, void 0, function* () {
            let list_of_task = yield create_list_of_tasks();
            let task_for_completing = Number(ctx.text.split(' ')[1]);
            if (task_for_completing === task_for_completing) {
                if (yield task_service_1.taskService.complete(task_for_completing)) {
                    let list_of_task = yield create_list_of_tasks();
                    let text_for_reply = `📝 ToDo Bot\nЗадача удалена.\nСписок задач:\n${list_of_task}`;
                    ctx.reply(text_for_reply, inline_1.keyboard_help);
                }
                else {
                    let text_for_reply = `📝 ToDo Bot\nНе получилось удалить задачу.\nСписок задач:\n${list_of_task}`;
                    ctx.reply(text_for_reply, inline_1.keyboard_help);
                }
                ;
            }
            else {
                let text_for_reply = `📝 ToDo Bot \
                \nЧтобы удалить задачу из списка, нужно отправить в чат команду, которая будет начинаться на /del \
                \nи через пробел будет указан номер задачи в списке. \
                \nСписок задач: \
                \n${list_of_task}`;
                ctx.reply(text_for_reply, inline_1.keyboard_help);
            }
            ;
        }));
    }
    ;
}
exports.TodoCommands = TodoCommands;
;
