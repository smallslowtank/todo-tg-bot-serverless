"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseCommands = void 0;
const inline_1 = require("../keyboards/inline");
const command_class_1 = require("./command.class");
const todo_commands_1 = require("./todo.commands");
class BaseCommands extends command_class_1.Command {
    handle() {
        // Start command
        this.bot.hears(/\/start|start|старт/i, (ctx) => __awaiter(this, void 0, void 0, function* () {
            ctx.react('🔥');
            let list_of_task = yield (0, todo_commands_1.create_list_of_tasks)();
            ctx.reply(`📝 ToDo Bot\nСписок задач:\n${list_of_task}`, inline_1.keyboard_help);
        }));
        // Halp page
        let help_page_text = `Это телеграм-бот для ведения списка задач. \
            \nЧтобы добавить задачу, \
            \nнужно написать её текст в чат бота \
            \nи в ответном сообщении нажать кнопку \
            \n'Add this message as a new Task' \
            \nДля удаления задачи из списка, \
            \nнужно отправить боту команду /del \
            \nи через пробел указать номер задачи в списке. \
            \nVersion: TypeScript`;
        // Help command and text
        this.bot.hears(/\/help|help/i, (ctx) => __awaiter(this, void 0, void 0, function* () {
            ctx.react('👀');
            ctx.reply(`📝 Help page\n${help_page_text}`, inline_1.keyboard_list);
        }));
        // Help callback
        this.bot.action('task_help', (ctx) => __awaiter(this, void 0, void 0, function* () {
            ctx.editMessageText(`📝 Help page\n${help_page_text}`, inline_1.keyboard_list);
        }));
    }
    ;
}
exports.BaseCommands = BaseCommands;
;
